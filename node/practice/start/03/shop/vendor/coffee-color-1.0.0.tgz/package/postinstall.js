// 示範用的 install script：真的惡意套件會在這裡偷 token、裝後門。這個只在你的專案根目錄留下一個記號檔
import { writeFileSync } from 'node:fs'
import { join } from 'node:path'
writeFileSync(join(process.env.INIT_CWD ?? process.cwd(), 'POSTINSTALL_RAN'), 'coffee-color 的 postinstall 執行過了\n')
console.log('coffee-color postinstall 執行了')

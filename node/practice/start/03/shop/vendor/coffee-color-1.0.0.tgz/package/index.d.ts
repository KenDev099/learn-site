export declare function colorOf(name: string): string | null

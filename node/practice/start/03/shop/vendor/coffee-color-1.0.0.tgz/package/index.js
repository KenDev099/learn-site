const colors = { espresso: '#3b2416', latte: '#c8a27c', milk: '#f5ecdf' }
export function colorOf(name) {
  return colors[name] ?? null
}
